
public class Account {
	double balance;
	
	public Account(double balance){
		this.balance = balance;
	}
}
